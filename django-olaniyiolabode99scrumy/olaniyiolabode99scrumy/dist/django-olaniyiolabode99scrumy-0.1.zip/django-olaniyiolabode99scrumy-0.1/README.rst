The application is called olaniyiolabode99scrumy 
You can access the route when you serve up the server
It has just one view that goes to /olaniyiolabode99scrumy