from django.apps import AppConfig


class Olaniyiolabode99ScrumyConfig(AppConfig):
    name = 'olaniyiolabode99scrumy'
